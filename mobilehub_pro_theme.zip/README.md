# MobileHub — Professional Single Page Theme (Light/Dark)

This package contains a polished single-page mobile information website optimized for GitHub Pages.
It uses a free public API: https://api-mobilespecs.azharimm.dev

## Files
- `index.html` — main page (includes header, search, and popup)
- `styles.css` — modern responsive styles with light/dark themes
- `script.js` — handles API calls, theme toggle, popup details, and search
- `README.md` — this file

## How to deploy (quick)
1. Create a GitHub repo (public) named `mobilehub`.
2. Upload these files to the repo root (do NOT upload the ZIP itself).
3. Enable GitHub Pages in Settings → Pages → Branch: `main` (root).
4. Wait a minute and open `https://<yourusername>.github.io/mobilehub/`

## Notes for AdSense
- Replace ad placeholders (elements with class `adsense`) with your AdSense code.
- Make sure you have at least 20-30 content entries and Privacy Policy page (can be a simple HTML file linked).
- GitHub Pages is supported by AdSense for content hosting.

## Troubleshooting
- If the API blocks requests (CORS) the site falls back to sample data.
- If you want me to prepare a `privacy.html` page, tell me and I'll add it.
