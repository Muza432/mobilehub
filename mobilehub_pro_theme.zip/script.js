// MobileHub script: fetch latest phones, show popup details, add theme toggle and search
const API_LATEST = "https://api-mobilespecs.azharimm.dev/v2/latest";
const MOBILE_LIST = document.getElementById('mobile-list');
const UPCOMING_LIST = document.getElementById('upcoming-list');
const LOADING = document.getElementById('mobile-loading');
const SEARCH = document.getElementById('search');
const POPUP = document.getElementById('popup');
const POPUP_BODY = document.getElementById('popup-body');
const POPUP_CLOSE = document.getElementById('popup-close');
const THEME_TOGGLE = document.getElementById('theme-toggle');

let mobilesData = [];

// Theme: check saved preference
(function initTheme(){
  const saved = localStorage.getItem('mh-theme');
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  setTheme(theme);
})();

function setTheme(t){
  if(t === 'dark'){
    document.documentElement.setAttribute('data-theme','dark');
    THEME_TOGGLE.textContent = '☀️';
    document.getElementById('meta-theme-color').setAttribute('content','#0b1220');
  } else {
    document.documentElement.removeAttribute('data-theme');
    THEME_TOGGLE.textContent = '🌙';
    document.getElementById('meta-theme-color').setAttribute('content','#ffffff');
  }
  localStorage.setItem('mh-theme', t);
}

THEME_TOGGLE.addEventListener('click', ()=>{
  const cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  setTheme(cur === 'dark' ? 'light' : 'dark');
});

// Fetch latest phones
async function fetchLatest(){
  try{
    const res = await fetch(API_LATEST);
    const json = await res.json();
    mobilesData = json.data.phones || [];
    if(mobilesData.length === 0) throw new Error("No phones returned");
    renderMobiles(mobilesData);
    LOADING.style.display = 'none';
  } catch(err){
    LOADING.textContent = "Could not fetch mobiles. Showing sample data.";
    mobilesData = sampleData();
    renderMobiles(mobilesData);
  }
}

function renderMobiles(list){
  MOBILE_LIST.innerHTML = list.map(m=> cardHtml(m)).join('');
  // attach event listeners for details (delegation)
  Array.from(document.getElementsByClassName('detail-btn')).forEach(btn => {
    btn.addEventListener('click', ()=> showDetails(btn.dataset.slug));
  });
}

function cardHtml(m){
  return `
    <article class="card">
      <img src="${m.image}" alt="${escapeHtml(m.phone_name)}">
      <h3>${escapeHtml(m.phone_name)}</h3>
      <div class="meta">Brand: ${escapeHtml(m.brand)}</div>
      <div class="meta">Release: ${m.year || 'N/A'}</div>
      <button class="btn detail-btn" data-slug="${m.slug}">View Details</button>
    </article>
  `;
}

async function showDetails(slug){
  POPUP.style.display = 'flex';
  POPUP.setAttribute('aria-hidden','false');
  POPUP_BODY.innerHTML = '<p class="muted">Loading specs...</p>';
  try {
    const res = await fetch(`https://api-mobilespecs.azharimm.dev/v2/${slug}`);
    const json = await res.json();
    const phone = json.data;
    POPUP_BODY.innerHTML = buildDetailsHtml(phone);
  } catch(e){
    POPUP_BODY.innerHTML = '<p class="muted">Failed to load details.</p>';
  }
}

POPUP_CLOSE.addEventListener('click', closePopup);
POPUP.addEventListener('click', (e)=> { if(e.target === POPUP) closePopup(); });
function closePopup(){ POPUP.style.display='none'; POPUP.setAttribute('aria-hidden','true'); POPUP_BODY.innerHTML=''; }

// Search filter
SEARCH.addEventListener('input', function(){
  const q = this.value.trim().toLowerCase();
  if(!q) return renderMobiles(mobilesData);
  const filtered = mobilesData.filter(m => m.phone_name.toLowerCase().includes(q) || (m.brand && m.brand.toLowerCase().includes(q)));
  renderMobiles(filtered.length ? filtered : sampleData());
});

// Build HTML for details
function buildDetailsHtml(phone){
  const specsHtml = (phone.specifications || []).map(sec=> {
    const items = (sec.specs || []).map(s => `<li><b>${escapeHtml(s.key)}:</b> ${escapeHtml(String(s.val))}</li>`).join('');
    return `<div class="spec-section"><h4>${escapeHtml(sec.title)}</h4><ul>${items}</ul></div>`;
  }).join('');
  return `
    <div>
      <h3 id="popup-title">${escapeHtml(phone.phone_name)}</h3>
      <img src="${phone.thumbnail}" alt="${escapeHtml(phone.phone_name)}" style="max-width:200px;border-radius:8px;display:block;margin:8px 0">
      <p class="meta"><b>Brand:</b> ${escapeHtml(phone.brand)} • <b>Release:</b> ${escapeHtml(phone.release_date || 'N/A')}</p>
      <div class="adsense" style="margin:12px 0">Ad Space (Details)</div>
      ${specsHtml || '<p class="muted">No specs available.</p>'}
      <p style="margin-top:12px"><a class="btn" href="https://api-mobilespecs.azharimm.dev/v2/${phone.slug}" target="_blank" rel="noopener">Open original source</a></p>
    </div>
  `;
}

// small helper to escape HTML from API
function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

// sample data used if API fails
function sampleData(){
  return [
    {"phone_name":"Sample Phone X","brand":"SampleBrand","image":"https://via.placeholder.com/400x300","slug":"sample-phone-x","year":"2024"},
    {"phone_name":"Classic Phone Z","brand":"Oldies","image":"https://via.placeholder.com/400x300","slug":"classic-phone-z","year":"2019"},
    {"phone_name":"FuturePhone Pro","brand":"Futura","image":"https://via.placeholder.com/400x300","slug":"futurephone-pro","year":"2025"}
  ];
}

// init
fetchLatest();
